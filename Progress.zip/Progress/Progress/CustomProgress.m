//
//  CustomProgress.m
//  Progress
//
//  Created by mac1 on 16/9/13.
//  Copyright © 2016年 Tucici. All rights reserved.
//

#import "CustomProgress.h"


#define Point self.bounds.size.width/2
#define lineWidth 5.0
@interface CustomProgress ()
{
    
    CGContextRef context;
}
@property (nonatomic, strong) NSMutableArray *nowArray;/*最后一段录制的红点绘制*/
@property (nonatomic, strong) NSMutableArray *pauseArray;/*绘制白点*/
@property (nonatomic, strong) NSArray *allArray;/*前面分段录制*/
@property (nonatomic, strong) UILabel *label;
@end

@implementation CustomProgress

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame])
    {
        self.backgroundColor = [UIColor lightGrayColor];
       self.label = [[UILabel alloc]initWithFrame:CGRectMake(0.0, 0.0, frame.size.width - 20.0, frame.size.height / 3)];
        [self.label.layer setBorderWidth:2.0];
        [self.label.layer setCornerRadius:5.0];
        [self.label.layer setBorderColor:[[UIColor whiteColor] CGColor]];
        [self.label setCenter:CGPointMake(frame.size.width / 2, frame.size.width / 2)];
        [self.label setTextColor:[UIColor whiteColor]];
        [self.label setTextAlignment:NSTextAlignmentCenter];
        [self addSubview:self.label];
        [self setNeedsDisplay];
    }
    return self;
}

- (void)drawRect:(CGRect)rect
{
    context = UIGraphicsGetCurrentContext();
    CGContextSetLineWidth(context, lineWidth);
    CGContextSetLineCap(context, kCGLineCapRound);
    CGContextSetStrokeColorWithColor(context, [[UIColor whiteColor] CGColor]);
    CGContextAddArc(context, Point, Point, Point- 2.5, M_PI_2 , M_PI_2 + 2 * M_PI, 0);
    CGContextStrokePath(context);
    if (!self.nowArray || self.nowArray.count < 2)
    {
        return;
    }
    
    ;
    // 历史
    for (int j = 0; j < self.allArray.count; j++)
    {
        NSMutableArray *tempArray = self.allArray[j];
        
        for (int i = 0; i < tempArray.count-1; i++)
        {
            CGContextSetStrokeColorWithColor(context, [self.drawColor CGColor]);
            CGFloat startAngle = M_PI_2 + 2 * M_PI * [tempArray[i] floatValue];
            CGFloat endAngle = M_PI_2 + 2 * M_PI * [tempArray[i+1] floatValue];
            CGContextAddArc(context, Point, Point, Point - 2.5, startAngle, endAngle, 0);
            CGContextStrokePath(context);
        }
    }
    
    // 本次
    for (int i = 0; i < self.nowArray.count-1; i++)
    {
        CGContextSetStrokeColorWithColor(context, [self.drawColor CGColor]);
        CGFloat startAngle = M_PI_2 + 2 * M_PI * [self.nowArray[i] floatValue];
        CGFloat endAngle = M_PI_2 + 2 * M_PI * [self.nowArray[i+1] floatValue];
        CGContextAddArc(context, Point, Point, Point - 2.5, startAngle, endAngle, 0);
        CGContextStrokePath(context);
    }
    
    // 暂停
    for (int j = 0; j < self.pauseArray.count; j++)
    {
        CGContextSetStrokeColorWithColor(context, [self.pauseColor CGColor]);
        CGFloat startAngle = M_PI_2 + 2 * M_PI * [self.pauseArray[j] floatValue];
        CGFloat endAngle = M_PI_2 + 2 * M_PI * [self.pauseArray[j] floatValue];
        CGContextAddArc(context, Point, Point, Point - 2.5, startAngle-0.01, endAngle+0.01, 0);
        CGContextStrokePath(context);
    }
}

- (void)setProgressEnd:(CGFloat)progressEnd
{
    _progressEnd = progressEnd;
 
    self.label.text = [NSString stringWithFormat:@"%0.2f%%",progressEnd*100];
    [self setNeedsDisplay];
}

- (void)drawBegan
{
    self.nowArray = [NSMutableArray array];
    [self.nowArray addObject:@(self.progressEnd)];
}

- (void)drawMoved
{
    [self.nowArray addObject:@(self.progressEnd)];
    [self setNeedsDisplay];
}
-(void)drawPause{
    NSMutableArray *tempArray = [[NSMutableArray alloc] initWithArray:self.nowArray];
    if (self.allArray)
    {
        self.allArray = [self.allArray arrayByAddingObject:tempArray];
    }
    else
    {
        self.allArray = [[NSArray alloc] initWithObjects:tempArray, nil];
    }
    [self.pauseArray addObject:@(self.progressEnd)];
}
- (void)drawEnded
{
    
    self.pauseArray  = nil;
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [self drawMoved];
        [self setNeedsDisplay];
    });
    
}

- (void)drawReset
{
    self.pauseArray  = nil;
    self.allArray    = nil;
    self.nowArray    = nil;
    self.progressEnd = 0.0;
    [self drawBegan];
    [self drawMoved];
    [self setNeedsDisplay];
}

- (UIColor *)drawColor
{
    if (!_drawColor)
    {
        _drawColor = [UIColor redColor];
    }
    return _drawColor;
}

- (NSMutableArray *)pauseArray
{
    if (!_pauseArray)
    {
        _pauseArray = [NSMutableArray array];
    }
    return _pauseArray;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
