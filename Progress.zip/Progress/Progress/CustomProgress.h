//
//  CustomProgress.h
//  Progress
//
//  Created by mac1 on 16/9/13.
//  Copyright © 2016年 Tucici. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomProgress : UIView
@property (nonatomic, assign) CGFloat progressEnd;
@property (nonatomic, strong) UIColor *pauseColor;
@property (nonatomic, strong) UIColor *drawColor;

/** 起始 */
- (void)drawBegan;
/** 过程 */
- (void)drawMoved;
/** 暂停 */
- (void)drawPause;
/** 结束 */
- (void)drawEnded;
/** 复位 */
- (void)drawReset;
@end
