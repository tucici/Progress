//
//  ViewController.m
//  Progress
//
//  Created by mac1 on 16/9/13.
//  Copyright © 2016年 Tucici. All rights reserved.
//

#import "ViewController.h"
#import "CustomProgress.h"
#define width_View self.view.frame.size.width
#define height_View self.view.frame.size.height
#define width_button ((self.view.frame.size.width-40)/3)
@interface ViewController (){
    NSTimer *timer;
    CGFloat time;
}
@property (nonatomic, strong) UIButton *button1;
@property (nonatomic, strong) UIButton *button2;
@property (nonatomic, strong) UIButton *button3;
@property (nonatomic, strong) CustomProgress *progress;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view setBackgroundColor: [UIColor whiteColor]];
    
    _button1 = [[UIButton alloc]initWithFrame:CGRectMake(10, 100, width_button, 60)];
    [_button1 setTitle:@"start" forState:UIControlStateNormal];
    [_button1 setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
    [_button1.layer setBorderWidth:2.0];
    [_button1.layer setCornerRadius:5.0];
    [_button1.layer setBorderColor:[[UIColor lightGrayColor] CGColor]];
    [_button1 addTarget:self action:@selector(start:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_button1];
    
    _button2 = [[UIButton alloc]initWithFrame:CGRectMake(width_View - width_button - 10.0, 100, width_button, 60)];
    [_button2 setTitle:@"pause" forState:UIControlStateNormal];
    [_button2 setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
    [_button2.layer setBorderWidth:2.0];
    [_button2.layer setCornerRadius:5.0];
    [_button2.layer setBorderColor:[[UIColor lightGrayColor] CGColor]];
    [_button2 addTarget:self action:@selector(pause:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_button2];
    
    _button3 = [[UIButton alloc]initWithFrame:CGRectMake(width_button + 20, 100, width_button, 60)];
    [_button3 setTitle:@"reset" forState:UIControlStateNormal];
    [_button3 setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
    [_button3.layer setBorderWidth:2.0];
    [_button3.layer setCornerRadius:5.0];
    [_button3.layer setBorderColor:[[UIColor lightGrayColor] CGColor]];
    [_button3 addTarget:self action:@selector(reset:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_button3];
    
    _progress =[[CustomProgress alloc]initWithFrame:CGRectMake(0.0, 0.0, 100, 100)];
    _progress.center=CGPointMake(self.view.center.x, height_View - 60);
    _progress.progressEnd = 0.0;
    _progress.drawColor =  [UIColor redColor];
    _progress.pauseColor = [UIColor whiteColor];
    [self.view addSubview:_progress];
    
    timer  = [NSTimer scheduledTimerWithTimeInterval:0.01 target:self selector:@selector(updataTime) userInfo:nil repeats:YES];
    [timer setFireDate:[NSDate distantFuture]];
    // Do any additional setup after loading the view.
}
-(void)updataTime{
    
    _progress.progressEnd +=0.001;NSLog(@"_progress.progressEnd   %f",_progress.progressEnd);
    [_progress drawMoved];
    if (_progress.progressEnd >=1.0) {
//        [_progress drawEnded];
        [timer setFireDate:[NSDate distantFuture]];
    }
}
-(void)start:(UIButton *)sender{
    
    if (_progress.progressEnd ==0.0) {
        [timer setFireDate:[NSDate distantPast]];
        [_progress drawBegan];
    }
    if (!_button2.selected) {
        [timer setFireDate:[NSDate distantPast]];
        [_progress drawMoved];
    }
}
-(void)pause:(UIButton *)sender{
    //    sender.selected
    NSLog(@"pause.selected: %d",sender.selected);
    if (_progress.progressEnd <=1.0 && _progress.progressEnd !=0.0) {
        [_progress drawPause];
    }
    //    sender.selected = !sender.selected;
    [timer setFireDate:[NSDate distantFuture]];
}

-(void)reset:(UIButton *)sender{
    [timer setFireDate:[NSDate distantFuture]];
    [_progress drawReset];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
